[Net.ServicePointManager]::SecurityProtocol = "Tls12, Tls11, Tls, Ssl3"
Invoke-WebRequest -Uri "https://github.com/OhGodACompany/OhGodAnETHlargementPill/raw/master/OhGodAnETHlargementPill-r2.exe" -OutFile OhGodAnETHlargementPill-r2.exe
